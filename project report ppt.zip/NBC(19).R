library(caret)
library(readr)
Insurance_Dataset_ <- read_csv("D:/new/Insurance Dataset .csv")
#View(Insurance_Dataset_)
Insurance_Dataset_ <- Insurance_Dataset_[,-c(1,6,8:10,14,20:23,25:27,29,30)]
str(Insurance_Dataset_)
data_factor <- as.data.frame(lapply(Insurance_Dataset_[,-c(15:18)],factor))
normalize <- function(x){
  return ( (x-min(x))/(max(x)-min(x)))
}
data_norm <- as.data.frame(lapply(Insurance_Dataset_[,c(15:18)],FUN=normalize))
final_data <- data.frame(data_factor,data_norm)
summary(final_data)
final_data <- na.omit(final_data)
sum(is.na(final_data))

set.seed(3)
final_data_1 <- final_data[sample(nrow(final_data)),]
train <- final_data_1[1:as.integer(0.70*nrow(final_data)),]
test <- final_data_1[-c(1:as.integer(0.70*nrow(final_data))),]

# Naive Bayes Model
library(e1071)
model_train <- naiveBayes(Result~.,data = train)

pred_train <- predict(model_train,train[,-15])
confusionMatrix(pred_train,train$Result)

pred_test <- predict(model_train,test[,-15])
confusionMatrix(pred_test,test$Result)



# Up Sampling
up_train <- upSample(train,train$Result)
model_up_train <- naiveBayes(Result~.,data = up_train[,-20])

pred_up_train <- predict(model_up_train,up_train[,-c(15,20)])
confusionMatrix(pred_up_train,up_train$Result)

pred_up_test <- predict(model_up_train,test[,-15])
confusionMatrix(pred_up_test,test$Result)





# Down Sampling
down_train <- downSample(train,train$Result)
model_down_train <- naiveBayes(Result~.,data = down_train[,-20])

pred_down_train <- predict(model_down_train,down_train[,-c(15,20)])
confusionMatrix(pred_down_train,down_train$Result)

pred_down_test <- predict(model_down_train,test[,-15])
confusionMatrix(pred_down_test,test$Result)




# under sampling
library(ROSE)
table(train$Result)
under_train <- ovun.sample(Result ~ ., data = train, method = "under",
                           N=361050,
                           seed = 3)$data
model_under_train <- naiveBayes(Result~.,data = under_train)

pred_under_train <- predict(model_under_train,under_train[,-15])
confusionMatrix(pred_under_train,under_train$Result)

pred_under_test <- predict(model_under_train,test[,-15])
confusionMatrix(pred_under_test,test$Result)





# over sampling
table(train$Result)
over_train <- ovun.sample(Result ~ ., data = train,
                          method = "over",
                          N=1085290,
                          seed = 3)$data
model_over_train <- naiveBayes(Result~.,data = over_train)

pred_over_train <- predict(model_over_train,over_train[,-15])
confusionMatrix(pred_over_train,over_train$Result)

pred_over_test <- predict(model_over_train,test[,-15])
confusionMatrix(pred_over_test,test$Result)





# Both sampling
table(train$Result)
both_train <- ovun.sample(Result ~ ., data = train, method = "both",
                          p = 0.5,
                          N=1085290,
                          seed = 3)$data
model_both_train <- naiveBayes(Result~.,data = both_train)

pred_both_train <- predict(model_both_train,both_train[,-15])
confusionMatrix(pred_both_train,both_train$Result)

pred_both_test <- predict(model_both_train,test[,-15])
confusionMatrix(pred_both_test,test$Result)















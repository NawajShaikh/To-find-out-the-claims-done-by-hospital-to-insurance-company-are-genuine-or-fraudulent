library(dplyr)
library(caret)
library(readr)
Insurance_Dataset_ <- read_csv("D:/new/Insurance Dataset .csv")
Insurance_Dataset_ <- Insurance_Dataset_[,-c(1:4,6,8:10,14,15,17,20:23,25:27,29,30:32)]
str(Insurance_Dataset_)
data_factor <- as.data.frame(lapply(Insurance_Dataset_[,-c(3,10,11)],factor))
normalize <- function(x){
  return ( (x-min(x))/(max(x)-min(x)))
}
data_norm <- as.data.frame(lapply(Insurance_Dataset_[c("Weight_baby","ratio_of_total_costs_to_total_charges")],FUN=normalize))
final_data <- data.frame(data_factor,data_norm,Insurance_Dataset_["Days_spend_hsptl"])
summary(final_data)
final_data <- na.omit(final_data)
sum(is.na(final_data))

set.seed(1)
final_data_1 <- final_data[sample(nrow(final_data)),]
train <- final_data_1[1:as.integer(0.70*nrow(final_data)),]
test <- final_data_1[-c(1:as.integer(0.70*nrow(final_data))),]

write.csv(final_data,"D:/new/DT/final_data_1.csv")

# Building a model using rpart on training data
library(rpart)
rpart <- rpart(Result~., data=train) 

pred_train <- predict(rpart,train[,-10])
pred_train <- data.frame(pred_train)
pred_train <- if_else(pred_train$Fraudulent > 0.5,"Fraudulent","Genuine")
pred_train <- as.factor(pred_train)
confusionMatrix(pred_train,train$Result) 

pred_rpart_test <- predict(rpart,newdata=test[,-10]) 
pred_rpart_test <- data.frame(pred_rpart_test)
pred_rpart_test <- if_else(pred_rpart_test$Fraudulent > 0.5,"Fraudulent","Genuine")
pred_rpart_test <- as.factor(pred_rpart_test)
confusionMatrix(pred_rpart_test,test$Result)  



set.seed(1)
# Up Sampling
up_train <- upSample(train,train$Result)

rpart_up <- rpart(Result~., data=up_train[,-13]) 

pred_up_train <- predict(rpart_up,up_train[,-c(10,13)])
pred_up_train <- data.frame(pred_up_train)
pred_up_train <- if_else(pred_up_train$Fraudulent > 0.5,"Fraudulent","Genuine")
pred_up_train <- as.factor(pred_up_train)
confusionMatrix(pred_up_train,up_train$Result) 

pred_up_test <- predict(rpart_up,newdata=test[,-10]) 
pred_up_test <- data.frame(pred_up_test)
pred_up_test <- if_else(pred_up_test$Fraudulent > 0.5,"Fraudulent","Genuine")
pred_up_test <- as.factor(pred_up_test)
confusionMatrix(pred_up_test,test$Result)  



set.seed(1)
# Down Sampling
down_train <- downSample(train,train$Result)

rpart_down <- rpart(Result~., data=down_train[,-13]) 

pred_down_train <- predict(rpart_down,down_train[,-13])
pred_down_train <- data.frame(pred_down_train)
pred_down_train <- if_else(pred_down_train$Fraudulent > 0.5,"Fraudulent","Genuine")
pred_down_train <- as.factor(pred_down_train)
confusionMatrix(pred_down_train,down_train$Result) 

pred_down_test <- predict(rpart_down,newdata=test) 
pred_down_test <- data.frame(pred_down_test)
pred_down_test <- if_else(pred_down_test$Fraudulent > 0.5,"Fraudulent","Genuine")
pred_down_test <- as.factor(pred_down_test)
confusionMatrix(pred_down_test,test$Result)  

# save the model to disk
saveRDS(rpart_down, "D:/new/DT/decision_tree_Model.rds")


# under sampling
library(ROSE)
table(train$Result)
under_train <- ovun.sample(Result ~ ., data = train,
                           method = "under",
                           N=361050, 
                           seed = 1)$data
rpart_under <- rpart(Result~., data=under_train) 

pred_under_train <- predict(rpart_under,under_train[,-10])
pred_under_train <- data.frame(pred_under_train)
pred_under_train <- if_else(pred_under_train$Fraudulent > 0.5,"Fraudulent","Genuine")
pred_under_train <- as.factor(pred_under_train)
confusionMatrix(pred_under_train,under_train$Result) 

pred_under_test <- predict(rpart_under,newdata=test[,-10]) 
pred_under_test <- data.frame(pred_under_test)
pred_under_test <- if_else(pred_under_test$Fraudulent > 0.5,"Fraudulent","Genuine")
pred_under_test <- as.factor(pred_under_test)
confusionMatrix(pred_under_test,test$Result)  




# over sampling
table(train$Result)
over_train <- ovun.sample(Result ~ ., data = train,
                          method = "over",
                          N=1085290,
                          seed = 1)$data

rpart_over <- rpart(Result~., data=over_train) 

pred_over_train <- predict(rpart_over,over_train[,-10])
pred_over_train <- data.frame(pred_over_train)
pred_over_train <- if_else(pred_over_train$Fraudulent > 0.5,"Fraudulent","Genuine")
pred_over_train <- as.factor(pred_over_train)
confusionMatrix(pred_over_train,over_train$Result) 

pred_over_test <- predict(rpart_over,newdata=test[,-10]) 
pred_over_test <- data.frame(pred_over_test)
pred_over_test <- if_else(pred_over_test$Fraudulent > 0.5,"Fraudulent","Genuine")
pred_over_test <- as.factor(pred_over_test)
confusionMatrix(pred_over_test,test$Result)  





# Both sampling
both_train <- ovun.sample(Result ~ ., data = train, method = "both",
                          p = 0.5,
                          N=1085290,
                          seed = 1)$data
prop.table(table(both_train$Result))

rpart_both <- rpart(Result~., data=both_train) 

pred_both_train <- predict(rpart_both,both_train[,-10])
pred_both_train <- data.frame(pred_both_train)
pred_both_train <- if_else(pred_both_train$Fraudulent > 0.5,"Fraudulent","Genuine")
pred_both_train <- as.factor(pred_both_train)
confusionMatrix(pred_both_train,both_train$Result) 

pred_both_test <- predict(rpart_both,newdata=test[,-10]) 
pred_both_test <- data.frame(pred_both_test)
pred_both_test <- if_else(pred_both_test$Fraudulent > 0.5,"Fraudulent","Genuine")
pred_both_test <- as.factor(pred_both_test)
confusionMatrix(pred_both_test,test$Result)  













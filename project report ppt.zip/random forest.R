library(dplyr)
library(caret)
library(readr)
Insurance_Dataset_ <- read_csv("D:/new/Insurance Dataset .csv")
Insurance_Dataset_ <- Insurance_Dataset_[,-c(1:4,6,8:10,14,15,17,20:23,25:27,29,30:32)]
str(Insurance_Dataset_)
data_factor <- as.data.frame(lapply(Insurance_Dataset_[,-c(3,10,11)],factor))
normalize <- function(x){
  return ( (x-min(x))/(max(x)-min(x)))
}
data_norm <- as.data.frame(lapply(Insurance_Dataset_[,c(10,11)],FUN=normalize))
final_data <- data.frame(data_factor,data_norm,Insurance_Dataset_["Days_spend_hsptl"])
summary(final_data)
final_data <- na.omit(final_data)
sum(is.na(final_data))
final_data <- final_data[1:100,]

set.seed(3)
final_data_1 <- final_data[sample(nrow(final_data)),]
train <- final_data_1[1:as.integer(0.70*nrow(final_data)),]
test <- final_data_1[-c(1:as.integer(0.70*nrow(final_data))),]



rf_model <- train(Result~.,data=train,method = "rf", ntree = 5) # random forest model building

pred_train <- predict(rf_model,train)
confusionMatrix(pred_train,train$Result) 

pred_test <- predict(rf_model,newdata=test) 
confusionMatrix(pred_test,test$Result)


set.seed(3)
# Up Sampling
up_train <- upSample(train,train$Result)

rf_up_model <- train(Result~.,data=up_train[,-13],method = "rf") # random forest model building

pred_up_train <- predict(rf_up_model,up_train[,-13])
confusionMatrix(pred_up_train,up_train$Result) 

pred_up_test <- predict(rf_up_model,newdata=test) 
confusionMatrix(pred_up_test,test$Result)




set.seed(3)
# Down Sampling
down_train <- downSample(train,train$Result)

rf_down_train <- train(Result~.,data=down_train[,-13],method = "rf", ntree = 5) # random forest model building

pred_down_train <- predict(rf_down_train,down_train[,-13])
confusionMatrix(pred_up_train,down_train$Result) 

pred_up_test <- predict(rf_down_train,newdata=test) 
confusionMatrix(pred_down_test,test$Result)

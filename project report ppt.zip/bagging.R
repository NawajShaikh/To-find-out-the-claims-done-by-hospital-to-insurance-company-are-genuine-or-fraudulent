library(dplyr)
library(caret)
library(readr)
Insurance_Dataset_ <- read_csv("D:/new/Insurance Dataset .csv")
Insurance_Dataset_ <- Insurance_Dataset_[,-c(1:4,6,8:10,14,15,17,20:23,25:27,29,30:32)]
str(Insurance_Dataset_)
data_factor <- as.data.frame(lapply(Insurance_Dataset_[,-c(10,11)],factor))
normalize <- function(x){
  return ( (x-min(x))/(max(x)-min(x)))
}
data_norm <- as.data.frame(lapply(Insurance_Dataset_[,c(10,11)],FUN=normalize))
final_data <- data.frame(data_factor,data_norm)
summary(final_data)
final_data <- na.omit(final_data)
sum(is.na(final_data))
final_data <- final_data[1:1000,]
set.seed(3)
final_data_1 <- final_data[sample(nrow(final_data)),]
train <- final_data_1[1:as.integer(0.70*nrow(final_data)),]
test <- final_data_1[-c(1:as.integer(0.70*nrow(final_data))),]





library(mlbench)
library(caret)
library(caretEnsemble)
control <- trainControl(method = "repeatedcv", number = 10,repeats = 3)
metric <- "Accuracy"
# Bagged CART
set.seed(3)
fit.treebag <- train(Result~.,data = train, method="treebag", metric=metric, trControl=control)
# Random Forest
set.seed(3)
fit.rf <- train(Result~.,data = train, method="rf", metric=metric, trControl=control)
# summarize results
bagging_results <- resamples(list(treebag=fit.treebag,rf=fit.rf))
summary(bagging_results)
dotplot(bagging_results)



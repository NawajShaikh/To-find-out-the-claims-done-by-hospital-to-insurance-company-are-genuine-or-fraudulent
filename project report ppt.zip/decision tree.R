library(dplyr)
library(caret)
library(readr)
Insurance_Dataset_ <- read_csv("D:/new/Insurance Dataset .csv")
Insurance_Dataset_ <- Insurance_Dataset_[,-c(1:4,6,8:10,14,15,17,20:23,25:27,29,30:32)]
str(Insurance_Dataset_)
data_factor <- as.data.frame(lapply(Insurance_Dataset_[,-c(3,10,11)],factor))
normalize <- function(x){
  return ( (x-min(x))/(max(x)-min(x)))
}
data_norm <- as.data.frame(lapply(Insurance_Dataset_[c("Weight_baby","ratio_of_total_costs_to_total_charges")],FUN=normalize))
final_data <- data.frame(data_factor,data_norm,Insurance_Dataset_["Days_spend_hsptl"])
summary(final_data)
final_data <- na.omit(final_data)
sum(is.na(final_data))

set.seed(1)
final_data_1 <- final_data[sample(nrow(final_data)),]
train <- final_data_1[1:as.integer(0.70*nrow(final_data)),]
test <- final_data_1[-c(1:as.integer(0.70*nrow(final_data))),]




library(rpart)

set.seed(1)
# Down Sampling
down_train <- downSample(train,train$Result)

rpart_down <- rpart(Result~., data=down_train[,-13]) 

pred_down_test <- predict(rpart_down,newdata=test) 
pred_down_test <- data.frame(pred_down_test)
pred_down_test <- if_else(pred_down_test$Fraudulent > 0.5,"Fraudulent","Genuine")
pred_down_test <- as.factor(pred_down_test)
confusionMatrix(pred_down_test,test$Result)  

# save the model to disk
saveRDS(rpart_down, "D:/new/DT/decision_tree_Model.rds")

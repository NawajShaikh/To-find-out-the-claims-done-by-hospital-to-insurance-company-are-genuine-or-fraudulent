library(dplyr)
library(caret)
library(readr)
Insurance_Dataset_ <- read_csv("D:/new/Insurance Dataset .csv")
Insurance_Dataset_ <- Insurance_Dataset_[,-c(1:4,6,8:10,14,15,17,20:23,25:27,29,30:32)]
str(Insurance_Dataset_)
data_factor <- as.data.frame(lapply(Insurance_Dataset_[,-c(10,11)],factor))
normalize <- function(x){
  return ( (x-min(x))/(max(x)-min(x)))
}
data_norm <- as.data.frame(lapply(Insurance_Dataset_[,c(10,11)],FUN=normalize))
final_data <- data.frame(data_factor,data_norm)
summary(final_data)
final_data <- na.omit(final_data)
sum(is.na(final_data))

set.seed(3)
final_data_1 <- final_data[sample(nrow(final_data)),]
train <- final_data_1[1:as.integer(0.70*nrow(final_data)),]
test <- final_data_1[-c(1:as.integer(0.70*nrow(final_data))),]

library(neuralnet)

# Building model
formula_nn <- paste("Result",paste(colnames(final_data[,-1]),collapse ="+"),sep="~")
insurance_model <- neuralnet(Result~.,data = train)
str(insurance_model)
plot(insurance_model)
# SSE sum of squared errors . least SSE best model
# Evaluating model performance
# compute function to generate ouput for the model prepared


training_results <- predict(insurance_model,train[,-1]) 
predict_train <- ifelse(training_results[,1] > training_results[,2],"Fraudulent","Genuine")
confusionMatrix(predict_train,train$Result)

testing_results <- predict(insurance_model,test[,-1]) 
predict_test <- ifelse(testing_results[,1] > testing_results[,2],"Fraudulent","Genuine")
confusionMatrix(predict_test,test$Result)





insurance_model_5 <- neuralnet(formula_nn,data=train,hidden = 5)
str(insurance_model_5)
plot(insurance_model_5)

training_results <- predict(insurance_model_5,train[,-1]) #we use predict instead of compute
predict_train <- ifelse(training_results[,1] > training_results[,2],"Fraudulent","Genuine")
# model_results$neurons
mean(predict_train==train$Result) #Training Accuracy = 92% 

testing_results <- predict(insurance_model_5,test[,-1]) #we use predict instead of compute
predict_test <- ifelse(testing_results[,1] > testing_results[,2],"Fraudulent","Genuine")
# model_results$neurons
mean(predict_test==test$Result) #Testing Accuracy = 67% 

# SSE has reduced and training steps had been increased as the number of nuerons 
# under hidden layer are increased


model_c <- neuralnet(formula_nn,data=train,hidden = c(7,3))
plot(model_c)

training_results <- predict(model_c,train[,-1]) #we use predict instead of compute
predict_train <- ifelse(training_results[,1] > training_results[,2],"Fraudulent","Genuine")
# model_results$neurons
mean(predict_train==train$Result) #Training Accuracy = 98.57% 

testing_results <- predict(model_c,test[,-1]) #we use predict instead of compute
predict_test <- ifelse(testing_results[,1] > testing_results[,2],"Fraudulent","Genuine")
# model_results$neurons
mean(predict_test==test$Result) #Testing Accuracy = 60% 

# SSE has reduced and training steps had been increased as the number of nuerons 
# under hidden layer are increased



